<?php
// lib/modules.php

function getClusterInfo($env) {
    $configPath = __DIR__ . "/../Clusters.ini";
    if (!file_exists($configPath)) {
        throw new Exception("Clusters.ini not found at $configPath");
    }

    $config = parse_ini_file($configPath, true);
    if (!isset($config[$env])) {
        throw new Exception("Unknown cluster: $env");
    }

    return $config[$env];
}
?>
