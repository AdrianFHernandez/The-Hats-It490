<?php 

require_once(__DIR__ . "/lib/modules.php");

$cluster = getClusterInfo("qa");
$webHost = $cluster["web_vm"];
echo "QA Web VM is at $webHost\n";


?>