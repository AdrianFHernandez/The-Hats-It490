<?php 


$config = parse_ini_file("bundle.ini", true);

$filesToInclude = array_unique($filesToInclude);


?>