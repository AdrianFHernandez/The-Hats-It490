#!/usr/bin/php
<?php

require_once("deploylib.php");

function prompt($label) {
    echo "$label: ";
    return trim(fgets(STDIN));
}

function showResponse($res) {
    if (isset($res['status']) && $res['status'] === "SUCCESS") {
        if (!empty($res['payload'])) {
            foreach ($res['payload'] as $key => $value) {
                if (is_array($value)) {
                    echo strtoupper($key) . ":\n";
                    foreach ($value as $entry) {
                        if (is_array($entry)) {
                            echo "  - " . json_encode($entry) . "\n";
                        } else {
                            echo "  - $entry\n";
                        }
                    }
                } else {
                    echo ucfirst($key) . ": $value\n";
                }
            }
        } else {
            echo "Success\n";
        }
    } else {
        $errorMsg = $res['payload']['message'] ?? $res["error"] ?? "Unknown error";
        echo "Error: $errorMsg\n";
    }
}

function menu() {
    echo "\n--- Deployment Menu ---\n";
    echo "1. Deploy new bundle\n";
    echo "2. List all bundles\n";
    echo "3. List versions for a bundle\n";
    echo "4. Rollback a bundle\n";
    echo "5. Exit\n";
    echo "Select option [1-5]: ";
    return trim(fgets(STDIN));
}

while (true) {
	$choice = menu();

    switch ($choice) {
        case "1":
	    
       	    system('clear');
	    $sourceDir = prompt("Enter path to bundle folder (must contain bundle.ini)");
            $res = createAndRegisterBundleFromIni($sourceDir);
            showResponse($res);
            break;

        case "2":
		 
       	    system('clear');
		$res = listBundleNames();
            showResponse($res);
            break;

        case "3":
		
       	    system('clear');
	$bundleName = prompt("Enter bundle name");
	    $res = listVersionsForBundle($bundleName);
            showResponse($res);
            break;

        case "4":
	   
       	    system('clear');
		$bundleName = prompt("Enter bundle name");
            $version = prompt("Enter version to roll back to");
            $res = rollbackToVersion($bundleName, $version);
            showResponse($res);
            break;

        case "5":
            echo "Exiting...\n";
            exit(0);

        default:
            echo "Invalid option. Try again.\n";
    }
}
