<?php 
require_once("lib/modules.php");

$cluster = getClusterInfo("prod"); 


print_r($cluster);



?>