#!/usr/bin/php
<?php

require_once("rabbitMQLib.inc");

$client = new rabbitMQClient("QAInstallRabbitMQ.ini","QADBInstallListener");



$request = [
    "type" => "INSTALL_BUNDLE",
    "payload" => [
        "host_user"     => "tds22-it490",                                  // Remote user
        "host_ip"       => "100.76.155.76",                                // Remote IP (installer cluster)
        "host_password" => "it490",                               // Password to fetch file via SCP
        "remote_path"   => "/home/tds22-it490/deploy_archive/login_package_v3.zip", // Path to bundle on deploy server
        "local_path"    => "/home/ubuntu/Desktop/login_package_v3.zip",                // Where installer will save it
        "sudo_password" => "ubuntu"                                     // For installer to use during execution
    ]
];

$response = $client->send_request($request);
print_r($response);


?>